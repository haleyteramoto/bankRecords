#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"

int debugmode = 0;

/*****************************************************************
//
//  //  Function name: addRecord
//  //
//  //  DESCRIPTION:   Adds a new record to the database in ascending
//  //                 order by account number. Does not accept duplicate
//  //                 account numbers.
//  //
//  //  Parameters:    records (struct record **): Pointer to the head of
//  //                 the record list.
//  //                 accountno (int): The account number to add.
//  //                 name (char []): The name for the new record.
//  //                 address (char []): The address for the new record.
//  //
//  //  Return values: 0 : Success
//  //                -1 : Duplicate account number found
//  //
//  ****************************************************************/

int addRecord (struct record **start, int uaccountno, char uname[], char uaddress[]) {
     if (debugmode) {
        printf("\n[DEBUG] Function: addRecord\n");
        printf("[DEBUG] Parameters: accountno = %d, uname = %s, uaddress = %s\n\n", uaccountno, uname, uaddress);
    }

    struct record *temp;
    struct record *current;
    struct record *previous;

    if (*start == NULL) {
	//list is empty
	temp = (struct record*)malloc(sizeof(struct record));
	if (temp == NULL) {
	    fprintf(stderr, "Error allocating memory.\n");
	    return -1;
	}

	temp->accountno = uaccountno;
	strncpy(temp->name, uname, sizeof(temp->name) - 1);
	temp->name[sizeof(temp->name) - 1] = '\0';
	strncpy(temp->address, uaddress, sizeof(temp->address) - 1);
	temp->address[sizeof(temp->address) - 1] = '\0';
	temp->next = NULL;

	*start = temp;
	return 0;
    }

    current = *start;
    previous = NULL;

    while (current != NULL) {
	if (current->accountno == uaccountno) {
	    return -1;
	}

	if (current->accountno > uaccountno) {
	    break;
	}

	previous = current;
	current = current->next;
    }

    temp = (struct record *)malloc(sizeof(struct record));
    if (temp == NULL) {
	fprintf(stderr, "Error allocating memory.\n");
	return -1;
    }

    temp->accountno = uaccountno;
    strncpy(temp->name, uname, sizeof(temp->name) - 1);
    temp->name[sizeof(temp->name) - 1] = '\0';
    strncpy(temp->address, uaddress, sizeof(temp->address) - 1);
    temp->address[sizeof(temp->address) - 1] = '\0';

    if (previous == NULL) {
	temp->next = *start;
	*start = temp;
    } else {
	temp->next = current;
	previous->next = temp;
    }

    return 0;
}

/*****************************************************************
//
//  //  Function name: printAllRecords
//  //
//  //  DESCRIPTION:   Prints all records in the database.
//  //
//  //  Parameters:    records (struct record *): Pointer to the head of
//  //                 the record list.
//  //
//  //  Return values: None
//  //
//  ****************************************************************/

void printAllRecords (struct record *start) {
    if (debugmode) {
        printf("\n[DEBUG] Function: printAllRecords\n");
        printf("[DEBUG] Called to print all records\n\n");
    }

    struct record *current = start;

    if (current == NULL) {
	printf("No records found.\n");
	return;
    }

    printf("Account No\tName\t\tAddress\n");
    printf("---------------------------------------\n");
    while (current != NULL) {
	printf("%d\t\t%s\t%s\n", current->accountno, current->name, current->address);
	current = current->next;
    }
}

/*****************************************************************
//
//  //  Function name: findRecord
//  //
//  //  DESCRIPTION:   Finds a record by account number and prints its
//  //                 details if found.
//  //
//  //  Parameters:    records (struct record *): Pointer to the head of
//  //                 the record list.
//  //                 accountno (int): The account number to find.
//  //
//  //  Return values: 0 : Record found and printed
//  //                -1 : Record not found
//  //
//  ****************************************************************/

int findRecord (struct record *start, int accountno) {
    if (debugmode) {
        printf("\n[DEBUG] Function: findRecord\n");
        printf("[DEBUG] Parameters: accountNum = %d\n\n", accountno);
    }

    struct record *current = start;

    while (current != NULL) {
	if (current->accountno == accountno) {
		printf("Account No: %d\nName: %s\nAddress: %s\n", current->accountno, current->name, current->address);
            return 0;
	    }
	current = current->next;
    }

    return -1;
}

/*****************************************************************
//
//  //  Function name: deleteRecord
//  //
//  //  DESCRIPTION:   Deletes a record with the specified account number
//  //                 from the database.
//  //
//  //  Parameters:    records (struct record **): Pointer to the head of
//  //                 the record list.
//  //                 accountno (int): The account number to delete.
//  //
//  //  Return values: 0 : Record deleted successfully
//  //                -1 : Record not found
//  //
//  ****************************************************************/

int deleteRecord (struct record **start, int uaccountno) {
    if (debugmode) {
        printf("\n[DEBUG] Function: deleteRecord\n");
        printf("[DEBUG] Parameters: accountNum = %d\n\n", uaccountno);
    }

    struct record *current = *start;
    struct record *previous = NULL;

    if (current == NULL) {
	return -1;
    }

    while (current != NULL) {
	if (current->accountno == uaccountno) {
	    //record found, delete
	    if (previous == NULL) {
		*start = current->next;//update start to next record
	    } else {
		previous->next = current->next;
	    }
	    free(current);
	    return 0;
	}
	previous = current;
	current = current->next;
    }

    //record not found
    return -1;
}

/*****************************************************************
//
//  //  Function name: writefile
//  //
//  //  DESCRIPTION:   Writes the records to a specified file.
//  //
//  //  Parameters:    records (struct record *): Pointer to the head of
//  //                 the record list.
//  //                 filename (char []): The name of the file to write to.
//  //
//  //  Return values: 0 : Success
//  //                -1 : Failure
//  //
//  ****************************************************************/

int writefile(struct record *start, char filename[]) {
    FILE *file = fopen(filename,  "w");
    if (file == NULL) {
	fprintf(stderr, "Error opening file for writing.\n");
	return -1;
    }

    struct record *current = start;
    while (current != NULL) {
	fprintf(file, "%d,%s,%s\n", current->accountno, current->name, current->address);
	current = current->next;
    }

    fclose(file);
    return 0;
}

/*****************************************************************
//
//  //  Function name: readfile
//  //
//  //  DESCRIPTION:   Reads records from a specified file and loads them
//  //                 into the database.
//  //
//  //  Parameters:    records (struct record **): Pointer to the head of
//  //                 the record list.
//  //                 filename (char []): The name of the file to read from.
//  //
//  //  Return values: Count of records read on success, -1 on failure
//  //
//  ****************************************************************/

int readfile(struct record **start, char filename[]) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
	fprintf(stderr, "Error opening file for reading.\n");
	return -1;
    }

    int uaccountno;
    char uname[100], uaddress[100];
    while (fscanf(file, "%d,%99[^,],%99[^\n]\n", &uaccountno, uname, uaddress) == 3) {
	if (addRecord(start, uaccountno, uname, uaddress) == -1) {
	    fprintf(stderr, "Duplicate account number found: %d\n", uaccountno);
	}
    }

    fclose(file);
    return 0;
}

/*****************************************************************
//
//  //  Function name: cleanup
//  //
//  //  DESCRIPTION:   Frees all allocated memory for the records
//  //                 and sets the head pointer to NULL.
//  //
//  //  Parameters:    records (struct record **): Pointer to the head of
//  //                 the record list.
//  //
//  //  Return values: None
//  //
//  ****************************************************************/

void cleanup(struct record **start) {
    struct record *current = *start;
    struct record *next;

    while (current != NULL) {
	next = current->next;
	free(current);
	current = next;
    }

    *start = NULL;
}
