/*****************************************************************
//  //  NAME:        Haley Teramoto
//  //
//  //  HOMEWORK:    3
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        September 28, 2024
//  //
//  //  FILE:        user_interface.c
//  //
//  //  DESCRIPTION:
//  //   ***Explain the code in your words***
//  //
//  //
//  ****************************************************************/

#include <stdio.h>
#include <string.h>
#include "database.h"
#include "record.h"

extern int debugmode;

void getaddress(char address[], int size);

/*****************************************************************
//  //  Function name: main
//  //
//  //  DESCRIPTION:   Displays the intro message and menu with 
//  //                 options for user to manage bank records.
//  //                 Loops until quit.
//  //
//  //  Parameters:    argc (int) : number of arguments
//  //                 argv (char*[]): array of arguments
//  //
//  //  Return values:  0 : success
//  //
//  ****************************************************************/

int main(int argc, char *argv[]) {
    struct record *start = NULL;
    char option[10];
    int accountno;
    char name[25];
    char address[45];
    int debugmode = 0;

    if (argc == 2) {
	if (strcmp(argv[1], "debug") == 0) {
	    debugmode = 1;
	} else {
	    printf ("Error: Invalid argument. Only 'debug' is accepted.\n");
	    return 1;
	}
    } else if (argc > 2) {
	printf("Error: Too many arguments.\n");
	return 1;
    }

    while (1) {
	printf ("Welcome to the Banking System\n");
	printf ("Menu options:\n");
	printf ("add: Add a new record\n");
	printf ("printall: Print all records\n");
	printf ("find: Find record by account number\n");
	printf ("delete: Delete record by account number\n");
	printf ("quit: Quit the program\n");

	printf ("Enter an option: ");
	fgets (option, sizeof(option), stdin);
	option[strlen(option) - 1] = '\0';

	if (strncmp(option, "add", 3) == 0 ||
	    strncmp(option, "a", 1) == 0 ||
	    strncmp(option, "ad", 2) == 0) {
	    while (1) {
		printf ("Enter account number: ");
	        while (scanf ("%d", &accountno) != 1 || accountno <= 0) {
		    printf ("Invalid account number. Enter a positive integer: ");
		    while (getchar() != '\n');
	        }
		if (findRecord(start, accountno) != -1) {
		    printf("Account number %d already exists. Please enter a different account number.\n", accountno);
            } else {
		break;
	    }
	}

	    getchar();
	    printf ("Enter name: ");
	    fgets (name, sizeof(name), stdin);
	    name [strlen(name) - 1] = '\0';

	    memset (address, 0, sizeof(address));
	    getaddress (address, sizeof(address));

	    addRecord (&start, accountno, name, address);
	    printf ("Record added successfully!\n");

	}

	else if (strncmp(option, "printall", 8) == 0 ||
		 strncmp(option, "p", 1) == 0 ||
		 strncmp(option, "pr", 2) == 0 ||
		 strncmp(option, "pri", 3) == 0 ||
		 strncmp(option, "prin", 4) == 0 ||
		 strncmp(option, "print", 5) == 0 ||
		 strncmp(option, "printa", 6) == 0 ||
		 strncmp(option, "printal", 7) == 0) {
	    printAllRecords (start);
	} else if (strncmp(option, "find", 4) == 0 ||
		   strncmp(option, "f", 1) == 0 ||
		   strncmp(option, "fi", 2) == 0 ||
		   strncmp(option, "fin", 3) == 0) {
	    printf ("Enter account number: ");
	    while (scanf ("%d", &accountno) != 1 || accountno <= 0) {
		printf ("Invalid account number. Enter a positive integer: ");
		while (getchar() != '\n');
	    }
	    getchar();

	    findRecord (start, accountno);
	}

	else if (strncmp(option, "delete", 6) == 0 ||
		 strncmp(option, "d", 1) == 0 ||
		 strncmp(option, "de", 2) == 0 ||
		 strncmp(option, "del", 3) ==0 ||
		 strncmp(option, "dele", 4) == 0 ||
		 strncmp(option, "delet", 5) == 0) {
	    printf ("Enter account number: ");
	    while (scanf ("%d", &accountno) != 1 || accountno <= 0) {
		printf ("Invalid account number. Enter a positive integer: ");
		while (getchar() != '\n');
	    }
	    getchar();

	    if (deleteRecord (&start, accountno)) {
		 printf ("Record not found!\n");
	    } else {
		printf ("Record deleted successfully!\n");
	    }

	} else if (strncmp(option, "quit", 4) == 0 ||
		   strncmp(option, "q", 1) == 0 ||
		   strncmp(option, "qu", 2) == 0 ||
		   strncmp(option, "qui", 3) == 0) {
	    break;
	} else {
	    printf ("Invalid option, please try again.\n");
	}
    }

    return 0;
}

/*****************************************************************
//  //  Function name: getaddress
//  //
//  //  DESCRIPTION:   Collects multi-line address from user.
//  //
//  //  Parameters:    adress (char[]) : array to store address
//  //                 size (int)      : side of array
//  //
//  //  Return values:  none
//  //
//  ****************************************************************/

void getaddress (char address[], int size) {
    char line[100];
    int len = 0;

    printf ("Enter the address:\n");

    while (fgets (line, sizeof(line), stdin) != NULL) {
	if (strcmp (line, "\n") == 0) break;
	if (len + strlen(line) >= size) break;
	strcat (address, line);
	len += strlen(line);
    }
}
