#include "record.h"

int addRecord(struct record **, int, char [], char []);
void printAllRecord(struct record *);
int findRecord(struct record *, int accNo);
int deleteRecord(struct record **, int accNo);
int writefile(struct record *, char filename[]);
int readfile(struct record **, char filename[]);
void cleanup(struct record **);
